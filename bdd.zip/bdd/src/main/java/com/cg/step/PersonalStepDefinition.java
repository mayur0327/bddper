package com.cg.step;


import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.bean.Education;
import com.cg.bean.Personal;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalStepDefinition {

	private WebDriver driver;
	private Personal pobj;
	private Education eobj;

	@Before
	public void setUpStepEnv() {
		System.setProperty("webdriver.chrome.driver", "lib/mydriver/chromedriver.exe");
	}

	@After
	public void destroy() {
		driver.quit();
	}
	
	@Given("^User is on 'PersonalDetails' Page$")
	public void user_is_on_PersonalDetails_Page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("C:\\Mayur\\Module 3\\bddworkspace\\MavenExampleBDD\\html\\PersonalDetails.html");
		pobj = new Personal();
		PageFactory.initElements(driver, pobj);
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		pobj.setFirstName("Mayur");
		pobj.setLastName("Hiwarkar");
		pobj.setEmail("mayur@gmail.com");
		pobj.setContact("9090909090");

		pobj.setAddressLine1("Airoli");
		pobj.setAddressLine2("Mumbai");
		pobj.clickCity(1);
		pobj.clickState(1);

		pobj.clickNext();
	}

	@Then("^display 'Personal details are validated'$")
	public void display_Personal_details_are_validated() throws Throwable {
		String expectedMessage = "Personal details are validated";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters url$")
	public void user_enters_url() throws Throwable {

	}

	@Then("^page should be loaded$")
	public void page_should_be_loaded() throws Throwable {
		String expectedPageTitle = "Step 1: Personal Details";
		String actualPageTitle = driver.getTitle();
		Assert.assertEquals(expectedPageTitle, actualPageTitle);
		Thread.sleep(2000);
		driver.close();
	}

	@When("^user enters invalid firstName$")
	public void user_enters_invalid_firstName() throws Throwable {
		pobj.setFirstName("");
		pobj.clickNext();

	}

	@Then("^display 'Please fill the First Name'$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		String expectedMessage = "Please fill the First Name";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

		driver.close();
	}

	@When("^user enters invalid lastName$")
	public void user_enters_invalid_lastName() throws Throwable {
		pobj.setFirstName("Mayur");
		pobj.setLastName("");
		pobj.clickNext();
	}

	@Then("^display 'Please fill the Last Name'$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		String expectedMessage = "Please fill the Last Name";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

		driver.close();
	}

	@When("^user enters invalid email$")
	public void user_enetrs_invalid_email() throws Throwable {
		pobj.setFirstName("Mayur");
		pobj.setLastName("Hiwarkar");
		pobj.setEmail("sjssj@ghsj");
		pobj.clickNext();
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
		String expectedMessage = "Please fill the Email";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter  email$")
	public void user_does_not_enter_email() throws Throwable {
		pobj.setFirstName("Mayur");
		pobj.setLastName("Hiwarkar");
		pobj.setEmail("");
		pobj.clickNext();
	}

	@Then("^display 'Please fill the Email id '$")
	public void display_Please_fill_the_Email_id() throws Throwable {
		String expectedMessage = "Please fill the Email id";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();

		driver.close();
	}

	@When("^user does not enter contact number$")
	public void user_does_not_enter_contact_number() throws Throwable {
		pobj.setFirstName("Mayur");
		pobj.setLastName("Hiwarkar");
		pobj.setEmail("mayur@gmail.com");
		pobj.setContact("");
		pobj.clickNext();
	}

	@Then("^display 'Please fill valid Contact number'$")
	public void display_Please_fill_valid_Contact_number() throws Throwable {
		String expectedMessage = "Please fill valid Contact number";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();

		driver.close();
	}

	@When("^user enters invalid contact number$")
	public void user_enters_invalid_contact_number() throws Throwable {
		pobj.setFirstName("Mayur");
		pobj.setLastName("Hiwarkar");
		pobj.setEmail("mayur@gmail.com");
		pobj.setContact("123311");
		pobj.clickNext();
	}

	@Then("^display 'Please fill valid number'$")
	public void display_Please_fill_valid_Contact_no() throws Throwable {
		String expectedMessage = "Please fill valid number";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().dismiss();

		driver.close();
	}

	@When("^user enters invalid first address line$")
	public void user_enters_invalid_first_address_line() throws Throwable {

		pobj.setFirstName("Mayur");
		pobj.setLastName("Hiwarkar");
		pobj.setEmail("mayur@gmail.com");
		pobj.setContact("9090909090");

		pobj.setAddressLine1("");
		pobj.clickNext();
	}

	@Then("^display 'Please fill valid first address line'$")
	public void display_Please_fill_valid_first_address_line() throws Throwable {
		String expectedMessage = "Please fill valid first address line";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

		driver.close();
	}

	@When("^user enters invalid second address line$")
	public void user_enters_invalid_second_address_line() throws Throwable {
		pobj.setFirstName("Mayur");
		pobj.setLastName("Hiwarkar");
		pobj.setEmail("mayur@gmail.com");
		pobj.setContact("9090909090");

		pobj.setAddressLine1("Airoli");
		pobj.setAddressLine2("");
		pobj.clickNext();
	}

	@Then("^display 'Please fill valid second address line'$")
	public void display_Please_fill_valid_second_address_line() throws Throwable {
		String expectedMessage = "Please fill valid second address line";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

		driver.close();
	}

	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
		pobj.setFirstName("Mayur");
		pobj.setLastName("Hiwarkar");
		pobj.setEmail("mayur@gmail.com");
		pobj.setContact("9090909090");

		pobj.setAddressLine1("Airoli");
		pobj.setAddressLine2("Mumbai");
		pobj.clickCity(0);
		pobj.clickNext();
	}

	@Then("^display 'Please fill correct City'$")
	public void display_Please_fill_City() throws Throwable {
		String expectedMessage = "Please fill correct City";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

		driver.close();
	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
		pobj.setFirstName("Mayur");
		pobj.setLastName("Hiwarkar");
		pobj.setEmail("mayur@gmail.com");
		pobj.setContact("9090909090");

		pobj.setAddressLine1("Airoli");
		pobj.setAddressLine2("Mumbai");
		pobj.clickCity(1);
		pobj.clickState(0);
		pobj.clickNext();
	}

	@Then("^display 'Please fill correct State'$")
	public void display_Please_fill_the_State() throws Throwable {
		String expectedMessage = "Please fill correct State";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

		driver.close();
	}

	@Given("^user is on Education Details page$")
	public void user_is_on_Education_Details_page() throws Throwable {
		driver = new ChromeDriver();
		driver.get("C:\\Mayur\\Module 3\\bddworkspace\\MavenExampleBDD\\html\\EducationalDetails.html");
		eobj = new Education();
		PageFactory.initElements(driver, eobj);
	}

	@When("^user enters loads the page$")
	public void user_enters_loads_the_page() throws Throwable {

	}

	@Then("^valid page should open$")
	public void valid_page_should_open() throws Throwable {
		String expectedPageTitle = "Step 2 : Educational Details";
		String actualPageTitle = driver.getTitle();
		Assert.assertEquals(expectedPageTitle, actualPageTitle);
		driver.close();
	}

	@When("^user enters invalid graduation stream$")
	public void user_enters_invalid_graduation_stream() throws Throwable {
		eobj.submiButton();

	}

	@Then("^displays 'Please select valid graduation stream'$")
	public void displays_Please_select_valid_graduation_stream() throws Throwable {
		String expectedMessage = "Please select valid graduation stream";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();

		driver.close();

	}

	@When("^user enters invalid graduation percentage$")
	public void user_enters_invalid_graduation_percentage() throws Throwable {
		eobj.clickStream();
		eobj.setGraduationPercentage("");
		eobj.submiButton();

	}

	@Then("^displays 'Please fill valid percentage'$")
	public void displays_Please_fill_valid_percentage() throws Throwable {
		String expectedMessage = "Please fill valid percentage";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();

		driver.close();

	}

	@When("^user enters invalid graduation year$")
	public void user_enters_invalid_graduation_year() throws Throwable {
		eobj.clickStream();
		eobj.setGraduationPercentage("80.0");
		eobj.setGraduationYear("");
		eobj.submiButton();
	}

	@Then("^displays 'Please fill valid graduation year'$")
	public void displays_Please_fill_valid_graduation_year() throws Throwable {
		String expectedMessage = "Please fill valid graduation year";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

		driver.close();

	}

	@When("^user enters invalid graduation project$")
	public void user_enters_invalid_graduation_project() throws Throwable {
		eobj.clickStream();
		eobj.setGraduationPercentage("80.0");
		eobj.setGraduationYear("2018");
		eobj.setGraduationProject("");
		eobj.submiButton();
	}

	@Then("^displays 'Please fill valid graduation project'$")
	public void displays_Please_fill_valid_graduation_project() throws Throwable {
		String expectedMessage = "Please fill valid graduation project";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

		driver.close();

	}

	@When("^user enters invalid technology$")
	public void user_enters_invalid_technology() throws Throwable {
		eobj.clickStream();
		eobj.setGraduationPercentage("80.0");
		eobj.setGraduationYear("2018");
		eobj.setGraduationProject("DMSA");
		eobj.submiButton();

	}

	@Then("^displays 'Please select valid technology'$")
	public void displays_Please_select_valid_technology() throws Throwable {
		String expectedMessage = "Please select valid technology";
		String actualMessage = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

		driver.close();

	}

	@When("^user enters valid  Education details$")
	public void user_enters_valid_Education_details() throws Throwable {
		eobj.clickStream();
		eobj.setGraduationPercentage("80.0");
		eobj.setGraduationYear("2018");
		eobj.setGraduationProject("DMSA");
		eobj.clickTechnology();
		eobj.submiButton();

	}

	@Then("^displays 'Your Registration is successfully done'$")
	public void displays_Your_Registration_is_successfully_done() throws Throwable {
		String expectedMessage = "Your Registration is successfully done";
		String actualMessage = driver.switchTo().alert().getText();

		Assert.assertEquals(expectedMessage, actualMessage);
		Thread.sleep(2000);
		driver.switchTo().alert().accept();

		driver.close();

	}

}
