package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Personal {

	@FindBy(id = "firstName")
	WebElement firstName;

	@FindBy(id = "lastName")
	WebElement lastName;

	@FindBy(id = "emailId")
	WebElement email;

	@FindBy(id = "number")
	WebElement contactNumber;

	@FindBy(id = "address1")
	WebElement addressLine1;

	@FindBy(id = "address2")
	WebElement addressLine2;

	@FindBy(name = "city")
	WebElement city;

	@FindBy(name = "state")
	WebElement state;

	@FindBy(id = "next")
	WebElement nextButton;

	public Personal() {
	}

	public String getFirstName() {
		return this.firstName.getAttribute("value");
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public String getLastName() {
		return this.lastName.getAttribute("value");
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public String getEmail() {
		return this.email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getContact() {
		return this.contactNumber.getAttribute("value");
	}

	public void setContact(String contactNo) {
		this.contactNumber.sendKeys(contactNo);
	}

	public String getAddressLine1() {
		return this.addressLine1.getAttribute("value");
	}

	public void setAddressLine1(String line1) {
		this.addressLine1.sendKeys(line1);
	}

	public String getAddressLine2() {
		return this.addressLine2.getAttribute("value");
	}

	public void setAddressLine2(String line2) {
		this.addressLine2.sendKeys(line2);
	}

	public void clickCity(int idx) {
		Select select = new Select(city);
		select.selectByIndex(idx);
	}

	public void clickState(int idx) {
		Select select =new Select(state);
		select.selectByIndex(idx);
	}

	public void clickNext() {
		nextButton.click();
	}

}
