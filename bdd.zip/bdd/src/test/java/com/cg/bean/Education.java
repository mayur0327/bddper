package com.cg.bean;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class Education {

	@FindBy(name = "graduation")
	WebElement graduationStream;

	@FindBy(id = "percentage")
	WebElement graduationPercentage;

	@FindBy(id = "year")
	WebElement graduationYear;

	@FindBy(id = "project")
	WebElement graduationProject;

	@FindBy(name = "technology")
	WebElement technologyUsed;

	@FindBy(id = "btnSubmit")
	WebElement submitButton;

	public Education() {
	}

	public void clickStream() {
		Select select = new Select(graduationStream);
		select.selectByVisibleText("Computer Engineering");
	}

	public String getGraduationPercentage() {
		return this.graduationPercentage.getAttribute("value");
	}

	public void setGraduationPercentage(String graduationPercentage) {
		this.graduationPercentage.sendKeys(graduationPercentage);
		
	}

	public String getGraduationYear() {
		return this.graduationYear.getAttribute("value");
	}

	public void setGraduationYear(String graduationYear) {
		this.graduationYear.sendKeys(graduationYear);
		;
	}

	public String getGraduationProject() {
		return this.graduationProject.getAttribute("value");
	}

	public void setGraduationProject(String graduationProject) {
		this.graduationProject.sendKeys(graduationProject);
		;
	}

	public void clickTechnology() {
		Select select = new Select(technologyUsed);
		select.selectByVisibleText("Android");
	}

	public void submiButton() {
		submitButton.click();
	}

}
